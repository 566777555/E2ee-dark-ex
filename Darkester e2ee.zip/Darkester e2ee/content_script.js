
let isRunning = false;
let currentMessages = [];
let currentSpeed = 5000;
let messageIndex = 0;

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.messages && request.speed) {
        // Start sending messages
        currentMessages = request.messages;
        currentSpeed = request.speed;
        messageIndex = 0;
        isRunning = true;
        sendNextMessage();
        sendResponse({status: "started"});
    } else if (request.stop) {
        // Stop sending messages
        isRunning = false;
        sendResponse({status: "stopped"});
    }
});

function sendNextMessage() {
    if (!isRunning || currentMessages.length === 0) {
        return;
    }

    // Get current message (loop infinitely)
    const message = currentMessages[messageIndex % currentMessages.length];
    
    // Find the message input box using the same selectors as the working sample
    const textbox = document.querySelector('[role="textbox"]') || document.querySelector('[contenteditable="true"]');
    
    if (textbox) {
        // Focus the textbox first
        textbox.focus();
        
        // Use the exact same method as the working sample
        document.execCommand('insertText', false, message);
        
        // Send the message after a short delay (same as sample)
        setTimeout(() => {
            const enterEvent = new KeyboardEvent('keydown', {
                key: 'Enter',
                code: 'Enter',
                keyCode: 13,
                which: 13,
                bubbles: true
            });
            textbox.dispatchEvent(enterEvent);
            
            // Move to next message for infinite loop
            messageIndex++;
            
            // Schedule the next message
            if (isRunning) {
                setTimeout(sendNextMessage, currentSpeed);
            }
        }, 1000);
    } else {
        // Retry finding textbox after a delay
        setTimeout(sendNextMessage, 2000);
    }
}
